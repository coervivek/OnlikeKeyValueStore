package com.online.keyvaluestore.service;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.keyvaluestore.doa.StoreDAO;

@Service
public class StoreServiceImpl implements StoreService {

	@Autowired
	private StoreDAO storeDAO;

	@Override
	public String set(String k, String v) {
		return storeDAO.set(k, v);
	}

	@Override
	public String get(String key) {
		return storeDAO.get(key);
	}

	@Override
	public String remove(String key) {
		return storeDAO.remove(key);
	}

	@Override
	public void clear() {
		storeDAO.clear();
	}

	@Override
	public boolean isPresent(String key) {
		return storeDAO.isPresent(key);
	}

	@Override
	public Set<String> getKeys() {
		return storeDAO.getKeys();
	}

	@Override
	public Set<String> getValues() {
		return storeDAO.getValues();
	}

	@Override
	public Map<String, String> getAll() {
		return storeDAO.getAll();
	}

}
