package com.online.keyvaluestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineKeyValueStoreRunner {
	public static void main(String[] args) {
		SpringApplication.run(OnlineKeyValueStoreRunner.class, args);
	}
}
