package com.online.keyvaluestore.doa;

import java.util.Map;
import java.util.Set;

public interface StoreDAO {
	String set(String k, String v);
	String get(String key);
	String remove(String key);
	boolean isPresent(String key);
	void clear();
	Set<String> getKeys();
	Set<String> getValues();
	Map<String, String> getAll();
}
