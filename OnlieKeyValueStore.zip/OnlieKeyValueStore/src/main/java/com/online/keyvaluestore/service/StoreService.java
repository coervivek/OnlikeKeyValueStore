package com.online.keyvaluestore.service;

import java.util.Map;
import java.util.Set;

public interface StoreService {
	String set(String k, String v);
	String get(String key);
	String remove(String key);
	void clear();
	boolean isPresent(String key);
	Set<String> getKeys();
	Set<String> getValues();
	Map<String, String> getAll();
}
