package com.online.keyvaluestore.doa;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class StoreDAOImpl implements StoreDAO {

	Logger logger = LoggerFactory.getLogger(StoreDAOImpl.class);

	private Map<String, String> store = null;

	@PostConstruct
	public void initStore() {
		logger.info("Initilizing online store");
		store = new ConcurrentHashMap();
	}

	@Override
	public String set(String k, String v) {
		String storedValue = getStore().put(k, v);
		return "Saved Successfully";
	}

	@Override
	public String get(String key) {
		return getStore().get(key);
	}

	@Override
	public String remove(String key) {
		return getStore().remove(key);

	}

	@Override
	public void clear() {
		getStore().clear();
	}

	@Override
	public boolean isPresent(String key) {
		return getStore().containsKey(key);
	}

	@Override
	public Set<String> getKeys() {
		return getStore().keySet().stream().collect(Collectors.toSet());
	}

	@Override
	public Set<String> getValues() {
		return getStore().values().stream().collect(Collectors.toSet());
	}

	@Override
	public Map<String, String> getAll() {
		return Collections.unmodifiableMap(getStore());
	}

	public Map<String, String> getStore() {
		return store;
	}

	public void setStore(Map<String, String> store) {
		this.store = store;
	}
}
