package com.online.keyvaluestore.conttroller;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.online.keyvaluestore.service.StoreService;

@RestController
public class StoreContoller {
	Logger logger = LoggerFactory.getLogger(StoreContoller.class);

	@Autowired
	private StoreService storeService;

	@GetMapping("/set")
	public ResponseEntity<String> set(@RequestParam(name = "k", required = true) String k,
			@RequestParam(name = "v", required = true) String v) {
		logger.info("/set with key: " + k + "value :" + v);
		return ResponseEntity.ok(storeService.set(k, v));
	}

	@GetMapping("/get")
	public ResponseEntity<String> get(@RequestParam(name = "k", required = true) String key) {
		logger.info("/get with key: " + key);
		String value = storeService.get(key);
		return (value != null) ? ResponseEntity.ok(value) : new ResponseEntity(HttpStatus.NOT_FOUND);

	}

	@GetMapping("/rm")
	public ResponseEntity<String> remove(@RequestParam(name = "k", required = true) String key) {
		logger.info("/rm with key: " + key);
		String removedValue = storeService.remove(key);
		if (removedValue != null) {
			return ResponseEntity.ok(removedValue + " removed from key store!");
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND, "key not found in store");
	}

	@DeleteMapping("/clear")
	public ResponseEntity clear() {
		logger.info("/clear");
		storeService.clear();
		return new ResponseEntity(HttpStatus.OK);
	}

	@GetMapping("/is")
	public ResponseEntity<String> isPresent(@RequestParam(name = "k", required = true) String key) {
		return storeService.isPresent(key) ? new ResponseEntity(HttpStatus.OK)
				: new ResponseEntity(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/getAll")
	public Map<String, String> getAll() {
		return storeService.getAll();
	}

	@GetMapping("/getKeys")
	public Set<String> getKeys() {
		return storeService.getKeys();
	}

	@GetMapping("/getValues")
	public Set<String> getValues() {
		return storeService.getValues();
	}
}
